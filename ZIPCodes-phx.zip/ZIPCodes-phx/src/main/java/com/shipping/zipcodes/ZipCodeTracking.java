package com.shipping.zipcodes;



import java.util.ArrayList;
import java.util.List;

class MergeIntervals {

    static class Tuple {
        private  int left;
        private int right;

        public  Tuple(int l, int r) {
            this.left = l;
            this.right = r;
        }
    }

        private static List<Tuple> merge_zipCodes(
                List<Tuple> v1) {

            if (v1.size() == 0) {
                return null;
            } else if (v1 == null) {
                return null;
            }

            List<Tuple> v2 =
                    new ArrayList<Tuple>();

            v2.add(new Tuple(v1.get(0).left, v1.get(0).right));

            for (int i = 1; i < v1.size(); i++) {
                int left1 = v1.get(i).left;
                int right1 = v1.get(i).right;
                int left2 = v2.get(v2.size() - 1).left;
                int right2 = v2.get(v2.size() - 1).right;

                if (right2 >= left1) {
                    v2.get(v2.size() - 1).right = Math.max(right1, right2);
                } else {
                    v2.add(new Tuple(left1, right1));
                }
            }

            return v2;
        }

        public static void main(String[] args) {
            List<Tuple> zipCodesRange = new ArrayList<>();

            zipCodesRange.add(new Tuple(94133,94133));
            zipCodesRange.add(new Tuple(94200, 94299));
            zipCodesRange.add(new Tuple(94600,94699));


            List<Tuple> v2 = merge_zipCodes(zipCodesRange);

            if (v2 != null) {
                for (int i = 0; i < v2.size(); i++) {
                    System.out.print(String.format("[%d,%d] ", v2.get(i).left, v2.get(i).right));
                }
            }

            System.out.println("\n");

            zipCodesRange.clear();


            zipCodesRange.add(new Tuple(94133,94133));
            zipCodesRange.add(new Tuple(94200, 94299));
            zipCodesRange.add(new Tuple(94226,94399));


            v2 = merge_zipCodes(zipCodesRange);

            for (int i = 0; i < v2.size(); i++) {
                System.out.print(String.format("[%d,%d] ", v2.get(i).left, v2.get(i).right));
            }



        }
    }
